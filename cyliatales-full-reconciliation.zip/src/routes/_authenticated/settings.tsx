import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import {
  Accessibility,
  BookOpenText,
  Check,
  Eye,
  Languages,
  RotateCcw,
  Save,
  Settings2,
  ShieldCheck,
  Sparkles,
  Volume2,
  WandSparkles,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import { ART_DIRECTION_BOARDS } from "@/lib/art-direction";
import { getStudioProviderStatus } from "@/lib/studio.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/settings")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Settings — CyliaTales" },
      {
        name: "description",
        content: "Shape how CyliaTales writes, reads and protects your stories.",
      },
    ],
  }),
  component: SettingsPage,
});

type Preferences = {
  readingAge: "0-3" | "5-7" | "9-12";
  language: string;
  bilingual: boolean;
  narration: boolean;
  dyslexiaFriendly: boolean;
  highContrast: boolean;
  reducedMotion: boolean;
  privateByDefault: boolean;
  reviewBeforeProduction: boolean;
  defaultPages: "8" | "12" | "16";
  artDirection: string;
};
const DEFAULTS: Preferences = {
  readingAge: "5-7",
  language: "English",
  bilingual: false,
  narration: true,
  dyslexiaFriendly: false,
  highContrast: false,
  reducedMotion: false,
  privateByDefault: true,
  reviewBeforeProduction: true,
  defaultPages: "12",
  artDirection: ART_DIRECTION_BOARDS[0].id,
};
const STORAGE_KEY = "cyliatales.preferences.v1";

function SettingRow({
  icon: Icon,
  title,
  description,
  checked,
  onCheckedChange,
}: {
  icon: typeof Accessibility;
  title: string;
  description: string;
  checked: boolean;
  onCheckedChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-5 border-b border-border/70 py-5 last:border-0">
      <div className="flex min-w-0 gap-3">
        <span className="settings-icon">
          <Icon className="h-4 w-4" />
        </span>
        <div>
          <p className="font-semibold">{title}</p>
          <p className="mt-1 max-w-xl text-sm leading-6 text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} aria-label={title} />
    </div>
  );
}

function SettingsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const getProviderStatus = useServerFn(getStudioProviderStatus);
  const [preferences, setPreferences] = useState<Preferences>(DEFAULTS);
  const [saved, setSaved] = useState(true);
  const [syncedFromAccount, setSyncedFromAccount] = useState(false);
  const [providerStatus, setProviderStatus] = useState<Awaited<
    ReturnType<typeof getStudioProviderStatus>
  > | null>(null);
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setPreferences({ ...DEFAULTS, ...JSON.parse(raw) });
    } catch {
      toast.error("Your saved preferences could not be loaded.");
    }
  }, []);
  useEffect(() => {
    getProviderStatus()
      .then(setProviderStatus)
      .catch(() => setProviderStatus(null));
  }, [getProviderStatus]);
  // The local cache above keeps the studio instant on load. The account's
  // saved preferences are the cross-device source of truth, so once they
  // arrive they win over whatever was only sitting in this browser.
  const { data: accountPreferences } = useQuery({
    queryKey: ["profile-preferences", user?.id],
    enabled: Boolean(user?.id),
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("preferences")
        .eq("id", user.id)
        .maybeSingle();
      if (error) throw error;
      return (data?.preferences as Partial<Preferences> | null) ?? null;
    },
  });
  useEffect(() => {
    if (accountPreferences && Object.keys(accountPreferences).length > 0) {
      const merged = { ...DEFAULTS, ...accountPreferences };
      setPreferences(merged);
      setSyncedFromAccount(true);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    }
  }, [accountPreferences]);
  const selectedBoard = useMemo(
    () =>
      ART_DIRECTION_BOARDS.find((board) => board.id === preferences.artDirection) ??
      ART_DIRECTION_BOARDS[0],
    [preferences.artDirection],
  );
  function update<K extends keyof Preferences>(key: K, value: Preferences[K]) {
    setPreferences((current) => ({ ...current, [key]: value }));
    setSaved(false);
  }
  async function save() {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    setSaved(true);
    if (!user) {
      toast.success("Preferences saved for this browser.");
      return;
    }
    const { error } = await supabase.from("profiles").update({ preferences }).eq("id", user.id);
    if (error) {
      toast.error(`Saved on this device, but syncing to your account failed: ${error.message}`);
      return;
    }
    setSyncedFromAccount(true);
    void qc.invalidateQueries({ queryKey: ["profile-preferences", user.id] });
    toast.success("Preferences saved and synced to your account.");
  }
  async function reset() {
    setPreferences(DEFAULTS);
    window.localStorage.removeItem(STORAGE_KEY);
    setSaved(true);
    if (user) {
      const { error } = await supabase
        .from("profiles")
        .update({ preferences: {} })
        .eq("id", user.id);
      if (!error) void qc.invalidateQueries({ queryKey: ["profile-preferences", user.id] });
    }
    toast.success("Preferences restored to CyliaTales defaults.");
  }
  return (
    <div>
      <PageHeader
        eyebrow="Studio control"
        title="Settings that protect the story."
        subtitle="Set the reading experience, creative defaults and safety posture once. CyliaTales carries them into the next production without hiding the decisions."
        actions={
          <Button onClick={save} disabled={saved}>
            {saved ? <Check /> : <Save />}
            {saved ? "Saved" : "Save changes"}
          </Button>
        }
      />
      <div className="settings-status mb-8 flex flex-wrap items-center justify-between gap-4 rounded-2xl border bg-card p-5 shadow-soft">
        <div className="flex items-center gap-3">
          <span className="settings-status-mark">
            <Settings2 className="h-5 w-5" />
          </span>
          <div>
            <p className="font-semibold">Your studio, your defaults</p>
            <p className="text-sm text-muted-foreground">
              {syncedFromAccount ? "Synced to your account" : "Saved on this device"} ·{" "}
              {user?.email ?? "signed-in creator"}
            </p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={reset}>
          <RotateCcw /> Restore defaults
        </Button>
      </div>
      <section
        className="mb-8 rounded-2xl border bg-card p-5 shadow-soft md:p-6"
        aria-labelledby="provider-status-title"
      >
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">
              Production infrastructure
            </p>
            <h2 id="provider-status-title" className="mt-2 text-xl font-semibold">
              AI provider connections
            </h2>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              Keys are checked server-side. Values are never sent to the browser or stored in
              preferences.
            </p>
          </div>
          <span className="rounded-full border bg-secondary px-3 py-1 text-xs font-semibold">
            {providerStatus?.baseUrlConfigured
              ? "Gateway configured"
              : "Gateway needs configuration"}
          </span>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Writing & safety", providerStatus?.text],
            ["Illustration", providerStatus?.image],
            ["ElevenLabs narration", providerStatus?.elevenLabs],
            ["Motion delivery", providerStatus?.motion],
          ].map(([label, connected]) => (
            <div
              key={label as string}
              className="flex items-center justify-between rounded-xl border bg-background/60 p-3"
            >
              <span className="text-sm font-medium">{label as string}</span>
              <span
                className={
                  connected
                    ? "text-xs font-semibold text-primary"
                    : "text-xs font-semibold text-muted-foreground"
                }
              >
                {connected ? "Connected" : "Not configured"}
              </span>
            </div>
          ))}
        </div>
      </section>
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-6">
          <section className="settings-card">
            <div className="settings-card-heading">
              <BookOpenText />
              <div>
                <h2>Reading profile</h2>
                <p>Shape language, pacing and the read-aloud experience.</p>
              </div>
            </div>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <label className="settings-field">
                <span>Reading age</span>
                <select
                  value={preferences.readingAge}
                  onChange={(e) =>
                    update("readingAge", e.target.value as Preferences["readingAge"])
                  }
                >
                  <option value="0-3">Ages 0–3 · first words</option>
                  <option value="5-7">Ages 5–7 · emerging reader</option>
                  <option value="9-12">Ages 9–12 · confident reader</option>
                </select>
              </label>
              <label className="settings-field">
                <span>Primary language</span>
                <select
                  value={preferences.language}
                  onChange={(e) => update("language", e.target.value)}
                >
                  <option>English</option>
                  <option>Français</option>
                  <option>Español</option>
                  <option>العربية</option>
                  <option>中文</option>
                  <option>日本語</option>
                </select>
              </label>
            </div>
            <div className="mt-2">
              <SettingRow
                icon={Languages}
                title="Bilingual reading"
                description="Keep the primary language and a second language together on the reading spread."
                checked={preferences.bilingual}
                onCheckedChange={(value) => update("bilingual", value)}
              />
              <SettingRow
                icon={Volume2}
                title="Narration by default"
                description="Prepare every approved page for read-aloud playback when a compatible voice is available."
                checked={preferences.narration}
                onCheckedChange={(value) => update("narration", value)}
              />
            </div>
          </section>
          <section className="settings-card">
            <div className="settings-card-heading">
              <Accessibility />
              <div>
                <h2>Comfort & access</h2>
                <p>Make story time easier to read, hear and navigate.</p>
              </div>
            </div>
            <div className="mt-2">
              <SettingRow
                icon={Eye}
                title="Dyslexia-friendly reading"
                description="Use a calmer reading treatment with stronger spacing and line length for longer sessions."
                checked={preferences.dyslexiaFriendly}
                onCheckedChange={(value) => update("dyslexiaFriendly", value)}
              />
              <SettingRow
                icon={Accessibility}
                title="High contrast controls"
                description="Increase contrast on navigation, status labels and interactive controls."
                checked={preferences.highContrast}
                onCheckedChange={(value) => update("highContrast", value)}
              />
              <SettingRow
                icon={Sparkles}
                title="Reduced motion"
                description="Keep page transitions and production previews calm for motion-sensitive readers."
                checked={preferences.reducedMotion}
                onCheckedChange={(value) => update("reducedMotion", value)}
              />
            </div>
          </section>
          <section className="settings-card">
            <div className="settings-card-heading">
              <WandSparkles />
              <div>
                <h2>Production defaults</h2>
                <p>Start each draft closer to the kind of story you actually make.</p>
              </div>
            </div>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <label className="settings-field">
                <span>Default page count</span>
                <select
                  value={preferences.defaultPages}
                  onChange={(e) =>
                    update("defaultPages", e.target.value as Preferences["defaultPages"])
                  }
                >
                  <option value="8">8 pages · short read</option>
                  <option value="12">12 pages · picture-book rhythm</option>
                  <option value="16">16 pages · extended world</option>
                </select>
              </label>
              <label className="settings-field">
                <span>Art direction</span>
                <select
                  value={preferences.artDirection}
                  onChange={(e) => update("artDirection", e.target.value)}
                >
                  {ART_DIRECTION_BOARDS.map((board) => (
                    <option key={board.id} value={board.id}>
                      {board.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <div className="mt-2">
              <SettingRow
                icon={Check}
                title="Review before production"
                description="Pause after the manuscript and storyboard so you can approve the world before generation begins."
                checked={preferences.reviewBeforeProduction}
                onCheckedChange={(value) => update("reviewBeforeProduction", value)}
              />
            </div>
          </section>
          <section className="settings-card">
            <div className="settings-card-heading">
              <ShieldCheck />
              <div>
                <h2>Privacy & sharing</h2>
                <p>Keep family stories and private references under your control.</p>
              </div>
            </div>
            <div className="mt-2">
              <SettingRow
                icon={ShieldCheck}
                title="Private by default"
                description="New stories remain private until you deliberately share or publish them."
                checked={preferences.privateByDefault}
                onCheckedChange={(value) => update("privateByDefault", value)}
              />
            </div>
          </section>
        </div>
        <aside className="settings-preview self-start rounded-2xl border bg-card p-5 shadow-soft xl:sticky xl:top-24">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">
            Live preference preview
          </p>
          <div className="settings-board mt-4 overflow-hidden rounded-xl">
            <img src={selectedBoard.image} alt="" />
            <div className="settings-board-caption">
              <p>{selectedBoard.name}</p>
              <span>{selectedBoard.medium}</span>
            </div>
          </div>
          <div className="mt-5 space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Reader</span>
              <strong>Ages {preferences.readingAge}</strong>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Language</span>
              <strong>
                {preferences.language}
                {preferences.bilingual ? " + bilingual" : ""}
              </strong>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Book length</span>
              <strong>{preferences.defaultPages} pages</strong>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Privacy</span>
              <strong>{preferences.privateByDefault ? "Private" : "Share-ready"}</strong>
            </div>
          </div>
          <div className="mt-5 border-t pt-5 text-sm leading-6 text-muted-foreground">
            <p className="flex gap-2">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> CyliaTales keeps your
              creative decisions visible and your story private until you choose otherwise.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
